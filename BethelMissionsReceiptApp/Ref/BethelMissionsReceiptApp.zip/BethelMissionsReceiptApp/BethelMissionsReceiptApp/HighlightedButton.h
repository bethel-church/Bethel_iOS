//
//  HighlightedButton.h
//  BethelMissionsReceiptApp
//
//  Created by Vivek Bhuria on 12/08/16.
//  Copyright © 2016 Calico. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HighlightedButton : UIButton

@end
