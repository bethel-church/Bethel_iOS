//
//  FiltersViewController.h
//  BethelMissionsReceiptApp
//
//  Created by Vivek Bhuria on 30/05/16.
//  Copyright © 2016 Calico. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FiltersViewController : UIViewController
@property (nonatomic,strong) NSString *mode;// Leader_Full, Leader_Partial, Student
@end
