//
//  CustomContentView.h
//  BethelMissionsReceiptApp
//
//  Created by Vivek Bhuria on 9/15/15.
//  Copyright (c) 2015 Calico. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomContentView : UIView

@end
